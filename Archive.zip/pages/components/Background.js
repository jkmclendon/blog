export default function Background () {
  return (
    <>
      <div className="app w-screen h-screen bg-fixed fixed" style={{backgroundImage: `url('https://res.cloudinary.com/dhjvvkko0/image/upload/v1674657203/gold_bg_zl7h55.png')`, backgroundSize: "cover", zIndex: '-1'}}></div><br /> <br />
    </>
  )
}