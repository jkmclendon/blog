import { Pool } from 'pg';

const db = new Pool();

export default db;